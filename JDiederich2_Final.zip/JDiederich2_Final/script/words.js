var words = ["javascript", "snowman", "school", "autobody", "country", 
						 "thunder", "jinxing", "staff", "shagginess", "bopped", "overjoyed"];
var lettersGuessed = [];
var buttonValue, currentWord, lettersOfCurrentWord, hangmanStructure; 

var win = "You Win!";
var lose = "Game Over! Better luck next time! ;)";
	
//*****************************************************************************
// Initializes the new game, loads canvas, draws hangman structure, and loads 
// current word.

function init() {	
		
	document.getElementById("init");

	function drawBoard() {        
		hangmanStructure = canvas.getContext('2d');
		hangmanStructure.beginPath();
		hangmanStructure.moveTo(100, 550);
		hangmanStructure.lineTo(300, 550);
		hangmanStructure.moveTo(200, 550);
		hangmanStructure.lineTo(200, 50);
		hangmanStructure.lineTo(500, 50);
		hangmanStructure.lineTo(500, 150);
		hangmanStructure.stroke();
	}

	drawBoard();		
	
//*****************************************************************************
// Displays the letter spaces of the current word to the screen using the HTML 
// id of "curWord". Chooses a random word from the "words" array.
	
	var letter;
	lettersOfCurrentWord = document.getElementById("curWord");

// This chunk of code was taken from example of a word guess game I found on the
// internetas I liked the layout. I originally removed parts that I didn't think were
// needed, like the .toUpperCase, as the exanoke of the game used the keyboard for 
// input with a form and I was using buttons with the value already upper case. 
// I later discovered that I needed the .toUpperCase anyways.

	currentWord = currentWord = words[Math.floor(Math.random() * words.length)];

	for (var i = 0; i < currentWord.length; i++) {
			letter = '<li class="letter letter' + currentWord.charAt(i).toUpperCase()
			+ '">' + currentWord.charAt(i).toUpperCase() + '</li>';

			lettersOfCurrentWord.insertAdjacentHTML('beforeend', letter);
	}
}

//*****************************************************************************
// Function to display the correct message depending on win or loss.

function gameOver(win) {
	if (win) {
		document.getElementById("message").innerHTML = win;
	} else {
			document.getElementById("message").innerHTML = lose;
	}
}

//*****************************************************************************
// Lives section
var lives = 6;

//*****************************************************************************
// Each function below gets the value from the corresponding switch statement 
// below and pushes the value to the lettersGuessed array to be used in 
// guess function.

function myFunction1 (num) {
		lettersGuessed.push("A");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction2 (num) {
		lettersGuessed.push("B");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction3 (num) {
		lettersGuessed.push("C");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction4 (num) {
		lettersGuessed.push("D");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction5 (num) {
		lettersGuessed.push("E");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction6 (num) {
		lettersGuessed.push("F");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction7 (num) {
		lettersGuessed.push("G");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction8 (num) {
		lettersGuessed.push("H");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction9 (num) {
		lettersGuessed.push("I");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction10 (num) {
		lettersGuessed.push("J");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction11 (num) {
		lettersGuessed.push("K");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction12 (num) {
		lettersGuessed.push("L");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction13 (num) {
		lettersGuessed.push("M");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction14 (num) {
		lettersGuessed.push("N");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction15 (num) {
		lettersGuessed.push("O");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction16 (num) {
		lettersGuessed.push("P");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction17 (num) {
		lettersGuessed.push("Q");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction18 (num) {
		lettersGuessed.push("R");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction19 (num) {
		lettersGuessed.push("S");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction20 (num) {
		lettersGuessed.push("T");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction21 (num) {
		lettersGuessed.push("U");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction22 (num) {
		lettersGuessed.push("V");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction23 (num) {
		lettersGuessed.push("W");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction24 (num) {
		lettersGuessed.push("X");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction25 (num) {
		lettersGuessed.push("Y");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

function myFunction26 (num) {
		lettersGuessed.push("Z");
		document.getElementById("lettersGuessed").innerHTML = lettersGuessed.join(", ");
		guess();
}

// Switch statement is used to pass the value of the button to the corresponding
// functions above.

function myFunction (button) {  
		buttonValue = button.id;
		switch (buttonValue) {
				case 'A':
						myFunction1(buttonValue);
						break;
				case 'B':
						myFunction2(buttonValue);
						break;
				case 'C':
						myFunction3(buttonValue);
						break;
				case 'D':
						myFunction4(buttonValue);
						break;
				case 'E':
						myFunction5(buttonValue);
						break;
				case 'F':
						myFunction6(buttonValue);
						break;
				case 'G':
						myFunction7(buttonValue);
						break;
				case 'H':
						myFunction8(buttonValue);
						break;
				case 'I':
						myFunction9(buttonValue);
						break;
				case 'J':
						myFunction10(buttonValue);
						break;
				case 'K':
						myFunction11(buttonValue);
						break;
				case 'L':
						myFunction12(buttonValue);
						break;
				case 'M':
						myFunction13(buttonValue);
						break;
				case 'N':
						myFunction14(buttonValue);
						break;
				case 'O':
						myFunction15(buttonValue);
						break;
				case 'P':
						myFunction16(buttonValue);
						break;
				case 'Q':
						myFunction17(buttonValue);
						break;
				case 'R':
						myFunction18(buttonValue);
						break;
				case 'S':
						myFunction19(buttonValue);
						break;
				case 'T':
						myFunction20(buttonValue);
						break;
				case 'U':
						myFunction21(buttonValue);
						break;
				case 'V':
						myFunction22(buttonValue);
						break;
				case 'W':
						myFunction23(buttonValue);
						break;
				case 'X':
						myFunction24(buttonValue);
						break;
				case 'Y':
						myFunction25(buttonValue);
						break;
				case 'Z':
						myFunction26(buttonValue);
						break;
				default:
						return false;
		}
  }


// Calls the information from the HTML document with the HTML tag "button"
// to be used in the the switch and functions above to for use in the guess 
//function.

var buttons = document.getElementsByTagName('button');

for(var i = 0, length = buttons.length; i < length; i++) {
		buttons[i].onclick = function () {
				myFunction (this);
		};
}

//*****************************************************************************
// Used to count how many times a letter is found in the currentWord to know
// when all of the letters are matched.

var numberOfTimesLettersMatched = 0;

// The "buttonValue" from above is turned into variable "guess" and then compared 
// with the "currentWord" in the HTML using the class of "letter" to verify if
// letter is included in the "currentWord". If the letter matches, the 
// "numberOfTimesLettersMatched" is incremented by that many times.  If "S" is
// found in the word 3 times, then the "numberOfTimesLettersMatched" increments by 
// 3. When "numberOfTimesLettersMatched" is equal to the "currentWord.length" the 
// game is over and won.

function guess() {	
	var guess = buttonValue;
	
	if(currentWord.indexOf(guess.toLowerCase()) > -1) {
		var lettersToShow;
		lettersToShow = document.querySelectorAll(".letter" + guess);

		for(var i = 0; i < lettersToShow.length; i++) {
			lettersToShow[i].classList.add("correct");
		}

		for (var j = 0; j < currentWord.length; j++) {
			if(currentWord.charAt(j).toUpperCase() === guess) {
				numberOfTimesLettersMatched++;
			}
		}

		if(numberOfTimesLettersMatched === currentWord.length) {
			gameOver(win);
		} 
	}
	
// If "guess" does not match "currentWord", "lives" is decremented by one and
// the corresponding part of the hangman structure is displayed.
	
		else {
			lives--;
			document.getElementById("lives").innerHTML = "You have " + 
				lives + " lives remaining!";
			
			if (lives == 5) {
				drawHead();
			}
			
			if (lives == 4) {
				drawBody();
			}
			
			if (lives == 3) {
				drawArm1();
			}
			
			if (lives == 2) {
				drawArm2();
			}
	
			if (lives == 1) {
				drawLeg1();
			}
	
			if (lives == 0) {
				drawLeg2();
			}
			
			if(lives === 0) {
				gameOver(lose);
			}
		}
}

//*****************************************************************************
// Draws the different parts of the hangman structure.

function drawHead() {
	head = canvas.getContext('2d');
	head.beginPath();
	head.arc(500, 200, 50, 0, 2 * Math.PI);
	head.stroke();
} 

function drawBody() {
	body = canvas.getContext('2d');
	body.beginPath();
	body.moveTo(500, 250);
	body.lineTo(500, 400);
	body.stroke();
}

function drawArm1() {
	arm1 = canvas.getContext('2d');
	arm1.beginPath();
	arm1.moveTo(425, 250);
	arm1.lineTo(500, 325);
	arm1.stroke();
}

function drawArm2() {
	arm2 = canvas.getContext('2d');
	arm2.beginPath();
	arm2.moveTo(575, 250);
	arm2.lineTo(500, 325);
	arm2.stroke();
}

function drawLeg1() {
	leg1 = canvas.getContext('2d');
	leg1.beginPath();
	leg1.moveTo(500, 400);
	leg1.lineTo(450, 500);
	leg1.stroke();
}

function drawLeg2() {
	leg2 = canvas.getContext('2d');
	leg2.beginPath();
	leg2.moveTo(500, 400);
	leg2.lineTo(550, 500);
	leg2.stroke();
}
